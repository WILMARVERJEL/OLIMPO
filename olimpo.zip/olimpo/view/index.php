<?php

?>
<!doctype html>
<html lang="es" dir="rtl">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.83.1">
    <title>OLIMPO v1.0</title>

    <!-- Bootstrap core CSS -->
	<link href="dist/css/bootstrap.rtl.min.css" rel="stylesheet">
	<link href="dist/css/dashboard.css" rel="stylesheet">

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style> 
    <!-- Custom styles for this template -->
    <link href="dist/css/dashboard.rtl.css" rel="stylesheet">
  </head>
  <body>
    
<header class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0 shadow">
  <a class="navbar-brand col-md-3 col-lg-2 me-0 px-3" href="#">OLIMPO</a>
  <button class="navbar-toggler pull-right d-md-none collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false">
    <span class="navbar-toggler-icon"></span>
  </button>
  <input class="form-control form-control-dark w-100" type="text" placeholder="Buscar">
  <ul class="navbar-nav px-3">
    <li class="nav-item text-nowrap">
      <a class="nav-link" href="librerias/logout.php">Salir</a>
    </li>
  </ul>
</header>

<div class="container-fluid">
  <div class="row">
    <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
      <div class="position-sticky pt-3">
        <ul class="nav flex-column">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="index.php">
              <span data-feather="home"></span>
                Inicio
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#" id="cargarProducto" >
              <span data-feather="file"></span>
               Productos
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">
              <span data-feather="shopping-cart"></span>
               Clientes
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">
              <span data-feather="users"></span>
              Usuarios
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">
              <span data-feather="bar-chart-2"></span>
              Informes
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">
              <span data-feather="layers"></span>
              Integrales
            </a>
          </li>
        </ul>

        <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
          <span>INFORMES GUARDADOS</span>
          <a class="link-secondary" href="#">
            <span data-feather="plus-circle"></span>
          </a>
        </h6>
        <ul class="nav flex-column mb-2">
          <li class="nav-item">
            <a class="nav-link" href="#">
              <span data-feather="file-text"></span>
               Mes actual
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">
              <span data-feather="file-text"></span>
              El ultimo trimestre
           </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">
              <span data-feather="file-text"></span>
                  Interacción social
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">
              <span data-feather="file-text"></span>
              Ventas de fin de año
           </a>
          </li>
        </ul>
      </div>
    </nav>

    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4" id="cargar">
      <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Tablero</h1>
          <div class="btn-toolbar mb-2 mb-md-0">
          <div class="btn-group me-2">
            <button type="button" class="btn btn-sm btn-outline-secondary">Exportar</button>
            <button type="button" class="btn btn-sm btn-outline-secondary">Participación</button>
          </div>
          <button type="button" class="btn btn-sm btn-outline-secondary dropdown-toggle">
            <span data-feather="calendar"></span>
              Esta semana
          </button>
        </div>
      </div>

<div class="card">
            <div class="card-header">
                <h3 class="card-title text-center">Productos</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <table  class="table table-bordered table-striped">
                    <thead>
                        <tr>
                          <th>Stock</th>
                          <th>Descripci&oacute;n</th>
                          <th>Precio</th>
                          <th>Nombre</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <?php 
                            include ('librerias/database.php');
                                $producto = new Database();
                                $listado=$producto->read();
                                while ($row=mysqli_fetch_object($listado)){
                                $id_producto=$row->id_producto;
                                $nombre=$row->nombre;
                                $precio=$row->precio;
                                $descripcion=$row->descripcion;
                                $stock=$row->stock;
                            ?>
                            <td><?php echo $stock;?></td>
                            <td><?php echo $descripcion?></td>
                            <td><?php echo $precio;?></td>
                            <td><?php echo $nombre;?></td>
                        </tr>
                        <?php
                        }
                        ?>            
                    </tbody>
                    <tfoot>
                        <tr>
                          <th>Stock</th>
                          <th>Descripci&oacute;n</th>
                          <th>Precio</th>
                          <th>Nombre</th>
                        </tr>
                    </tfoot>
                </table>
            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.card -->    
            <canvas class="my-4 w-100" id="myChart" width="900" height="380"></canvas>

    </main>
  </div>
</div>

	<!-- jQuery -->
    <script src="plugins/jquery/jquery.min.js"></script>
    <!-- Bootstrap 4 -->
    <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- AdminLTE App -->
    <script src="dist/js/adminlte.min.js"></script>

    <!-- DataTables -->
    <script src="plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
    <script src="plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
    <script src="plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>

    <!-- Toastr -->
    <script src="plugins/toastr/toastr.min.js"></script>	
    <script src="dist/js/bootstrap.bundle.min.js"></script>
    <script src="dist/js/feather.min.js"></script>
    <script src="dist/js/Chart.min.js"></script>
    <script src="dist/js/dashboard.js"></script>
    <script src="dist/js/jquery-3.6.0.js"></script>
    <script src="dist/js/jquery-3.6.0.min.js"></script>
    
   <script type="text/javascript">
    	$('#cargarProducto').click(function(){
    		$.ajax({
    			url:"view/productos.php",
    			beforeSend:function(){
    				$('#cargar').text('Cargando...');
    			} ,
    			success : function(data){
    				setTimeout(function(){
    					$('#cargar').html(data);
    				 },
    				 );
    			}
    		});
    	});
    </script>
   
  </body>
</html>
