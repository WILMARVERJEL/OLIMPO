<?php 
                include ("../librerias/database.php");
                $producto= new Database();
                
                if(isset($_POST) && !empty($_POST)){
                    $nombre = $producto->sanitize($_POST['nombre']);
                    $precio = $producto->sanitize($_POST['precio']);
                    $descripcion = $producto->sanitize($_POST['descripcion']);
                    $stock = $producto->sanitize($_POST['stock']);
                    $id_producto=intval($_POST['id_producto']);
                    $res = $producto->update($nombre, $precio, $descripcion, $stock ,$id_producto);
                    
                    $datos_producto=$producto->single_record($id_producto);
                }
    
            ?>
