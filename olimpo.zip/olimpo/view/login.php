<?php
?>
<!doctype html>
 <html lang="es">
  <head>
   <meta charset="utf-8">
   <title>Olimpo</title>
   <!--Estilo Css-->
   <link rel="stylesheet" type="text/css" href="dist/css/style.css?v=1">
        </head>
        <body>
        <div class="container">
        <h1 class="text">OLIMPO</h1>
		<form class="form" method="post">
            <div class="message"> <?php
              if(isset($errorLogin)){
                echo $errorLogin;
              }
            ?>
            </div>
		        <input class="form-control" type="email" name="email" placeholder="Email" maxlength="50"><br>
		        <input class="form-control" type="password" name="password" placeholder="Password" maxlength="8"minlength="8"><br>
		        <button class="button" type="submit">Iniciar Sesi&oacute;n</button>
		 </form>
		</div>
  </body>
</html>
<?php
?>