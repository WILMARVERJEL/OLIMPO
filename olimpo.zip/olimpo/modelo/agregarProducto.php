<?php
				include ("../librerias/database.php");
				$producto= new Database();
				if(isset($_POST) && !empty($_POST)){
					$nombre = $producto->sanitize($_POST['nombre']);
					$precio = $producto->sanitize($_POST['precio']);
					$descripcion = $producto->sanitize($_POST['descripcion']);
					$stock = $producto->sanitize($_POST['stock']);
					
					$res = $producto->create($nombre, $precio, $descripcion, $stock);
					
					?>
				<div class="<?php echo $class?>">
				  <?php header("Location: ../index.php");?>
				</div>	
					<?php
				}
	
			?>
<script src="../dist/js/sweetalert.min.js"></script>