<?php 
if (isset($_GET['id_producto'])){
	include('../librerias/database.php');
	$producto = new Database();
	$id_producto=intval($_GET['id_producto']);
	$res = $producto->delete($id_producto);
	if($res){
		header('location: ../index.php');
	}else{
		echo "Error al eliminar el registro";
	}
}
?>