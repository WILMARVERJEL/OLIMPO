
<!DOCTYPE html>
 <html>
 <head>
 	<link rel="stylesheet" href="dist/css/modal.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
    <link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
    <link rel="stylesheet" href="plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="../plugins/dist/css/adminlte.min.css">
    


 </head>
 <body id="cargar">
 	<!--<button class="btnagregar">Agregar</button>-->
<div class="card">
            <div class="card-header">
                <h3 class="card-title">Productos</h3>
                <button type="button" class="btn btn-success float-right" data-toggle="modal" data-target="#ventana_modal" onclick="vistaAgregarProducto()"><i class="far fa-plus-square"></i> Agregar</button>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <table  class="table table-bordered table-striped">
                    <thead>
                        <tr>
                        	<th>Acci&oacute;n</th>
                        	<th>Stock</th>
                        	<th>Descripci&oacute;n</th>
                        	<th>Precio</th>
                        	<th>Nombre</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <?php 
                            include ('../librerias/database.php');
                                $producto = new Database();
                                $listado=$producto->read();
                                while ($row=mysqli_fetch_object($listado)){
                                $id_producto=$row->id_producto;
                                $nombre=$row->nombre;
                                $precio=$row->precio;
                                $descripcion=$row->descripcion;
                                $stock=$row->stock;
                            ?>
                            <td>
                            <a href="modelo/eliminarProducto.php?id_producto=<?php echo $id_producto;?>" class="fas fa-trash-alt text-danger lead" title="Editar" data-toggle="tooltip"><i class="material-icons"></i>&nbsp;&nbsp;&nbsp;</a>

                            <a href="modelo/actualizarProducto.php?id_producto=<?php echo $id_producto;?>" class="far fa-edit text-primary lead" title="Editar" data-toggle="tooltip"><i class="material-icons"></i></a>
                            <td><?php echo $stock;?></td>
                            <td><?php echo $descripcion?></td>
                            <td><?php echo $precio;?></td>
                            <td><?php echo $nombre;?></td>
                        </tr>
                        <?php
                        }
                        ?>           	
                    </tbody>
                    <tfoot>
                        <tr>
                            <th>Acci&oacute;n</th>
                        	<th>Stock</th>
                        	<th>Descripci&oacute;n</th>
                        	<th>Precio</th>
                        	<th>Nombre</th>
                        </tr>
                    </tfoot>
                </table>
            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.card -->      
<div id="modalAgregar" class="modalDialog">
	<div>
		<a href="#close" title="Close" class="close" onclick="javascript:cerrarModal();">X</a>
		<form  role="form" method="post" action="modelo/agregarProducto.php">
		<h3 class="text-center">Agregar producto</h3>
		  <div class="col-md-12">
		    <input name="nombre" id="nombre" type="text" class="form-control" placeholder="Nombre">
		  </div>
          <br>
		  <div class="col-md-12">
		    <input name="precio" id="precio" type="text" class="form-control" placeholder="Precio">
		  </div>
          <br>
		  <div class="col-md-12">
		    <textarea  placeholder="Descripcion" name="descripcion" id="descripcion" class='form-control' maxlength="255" required></textarea>
		  </div>
          <br>
		  <div class="col-md-12">
		    <input name="stock" id="stock" type="text" class="form-control" placeholder="stock">
		  </div>
          <br>
		  <button type="submit" class="btn btn-success">Guardar</button>
         </form>
	</div>
</div>


<script src="dist/js/sweetalert.min.js"></script>
<script type="text/javascript"> 
	function vistaAgregarProducto(){
		    document.getElementById('modalAgregar').style.display = 'block';
		    }
    function vistaEditarProducto(){
            document.getElementById('modalEditar').style.display = 'block';
            }
	function cerrarModal() {
	  document.getElementById('modalAgregar').style.display = 'none';
      document.getElementById('modalEditar').style.display = 'none';
	}
    function vistaEliminarProducto(){
        swal({
          title: "? Desea eliminar producto",
          text: "! Esto eliminará permanentemente su producto ",
          icon: "warning",
          buttons: true,
          dangerMode: true,
        })
        .then((willDelete) => {
          if (willDelete) {
            <?php 
            if (isset($_GET['id_producto'])){
                include('../librerias/database.php');
                $Producto = new Database();
                $id_producto=intval($_GET['id_producto']);
                $res = $producto->delete($id_producto);
            }
            ?>
            swal("! Producto eliminado", {
              icon: "success",
            });
          } else {
            swal("! Ha cancelado eliminar producto");
          }
        });
    }
    function cargarProducto(){
        swal({
          title: "Agregado correctamente!",
          icon: "success",
          button: "ok!",
        });
    }
</script>
<script type="text/javascript">
    	$('#cargarProducto').click(function(){
    		$.ajax({
    			url:"../view/productos.php",
    			beforeSend:function(){
    				$('#cargar').text('Cargando...');
    			} ,
    			success : function(data){
    				setTimeout(function(){
    					$('#cargar').html(data);
    				 },
    				 );
    			}
    		});
    	});
    </script>
    <!-- jQuery -->
    <script src="plugins/jquery/jquery.min.js"></script>
      <!-- AdminLTE for demo purposes -->
    <script src="plugins/dist/js/demo.js"></script>
    <script src="plugins/dist/js/adminlte.min.js"></script>
    <!-- DataTables -->
    <script src="plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
    <script src="plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
    <script src="plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
    <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
 
 </body>
 </html>